
Election Voting dapp on the Tezos blockchain platform

Elections are under threat from malicious actors that can infiltrate voting machines, alter voter registration databases, coordinate disinformation campaigns, and more. Blockchain technology could help here